/* *******************Developer : infiSTAR (infiSTAR23@gmail.com)******************* */
/* ******************Copyright � 2014 infiSTAR all rights reserved****************** */
/* *********************************www.infiSTAR.de********************************* */
--------------------------------------------------------------------------------
Hello,
just follow the Installation-Guide at the bottom and the setup should be really easy.
If you encounter problems you can contact infiSTAR23@gmail.com (please use either the paypal mail account or put your OrderID within the mail).

The filter for BE are regex and made to support the tools and detect hackers. Not using BE or some kind of No-Cdkey Server is not recommended.
The .dll files (http://files.dayzantihack.de/Extra_Files.zip) are not essential and only an addition.
All Logs can be found in the server .rpt file as well.
My PlayerID is by default in the Superadmin array as I sometimes have to join servers and use the tools to find problems with custom scripts.
You are allowed to remove it but it would make no difference since I am not going to join your server to use this access unless you have asked me to do so.

cheers,
Chris aka infiSTAR
--------------------------------------------------------------------------------
As a friendly Reminder, you have accepted this by proceeding the payment during the purchase:
*REFUND POLICY*
You agree that infiSTAR offers no refunds and all payments for Services are final. 
Furthermore, you shall not institute any form or charge-back for any fees paid to infiSTAR. 
You acknowledge that you have read and agree to the above Policy.

*TERMS AND CONDITIONS*
The script (which is a plain written text) stays property of infiSTAR.
As author he is the only one allowed to modify, share (sell or post) it.
Commercial use is prohibited unless it is permitted by infiSTAR.
Copyright � 2014 infiSTAR all rights reserved
--------------------------------------------------------------------------------
CONTACT INFO
http://dayzantihack.com/form.html (infiSTAR23@gmail.com)
--------------------------------------------------------------------------------
KEY-BINDINGS: (can be seen ingame as well)
Epoch Only:
  1 - Open/Unlock Door/Vehicle CursorTarget
  2 - Close/Lock Door/Vehicle CursorTarget
  I - Show Lock Code CursorTarget
  U - Generate Key CursorTarget
  Insert - Save Building/Vehicle to Database/Hive
  F4 - Base Destruction Menu
Possible on All Mods (yes, including Epoch):
  4 - Fly Up
  5 - TP LookingDirection
  End - Toggle DebugMonitor
  Delete - Delete CursorTarget
  F5 - Map options!
  F9 - ShowGear Target
  F10 - UnSpectate Target
Tip:
  DoubleClick Player To Spectate
--------------------------------------------------------------------------------
If you see anyone else reselling, leaking, sharing anything from me -
Please gather as much information as possible and let me know please.

advice:
do not trust or pay:
GamerzFactory.de, OCIR** GmbH, Dami, nullbyte, x00, finest
Those are companies/people that I have blacklisted due to reselling my work without permission.
--------------------------------------------------------------------------------
Installation-Guide:
01.	Extra Files and some helpful screen-shots can be found here:
		http://files.dayzantihack.de/
01.	get something to extract a .pbo file (I recommend 'pbo manager'). // http://www.armaholic.com/page.php?id=16369
02.	get the "dayz_server.pbo" file from your Server.
03.	extract the file.	// (right click -> PBO MANAGER -> Extract to dayz_server\)
04.	open dayz_server -> init -> "server_functions.sqf" with notepad or something semilar.
05.	go to the very TOP of the "server_functions.sqf" file
06.	copy paste:
		[] execVM "\z\addons\dayz_server\init\AH.sqf";
// (AT THE VERY TOP OF server_functions.sqf ABOVE EVERYTHING ELSE!)
07.	Now you extract the AntiHack Script, you purchased, in dayz_server -> init -> here. (same location like "server_functions.sqf")
08.	"AHconfig.sqf" and "AH.sqf" have to be in the same folder then "server_functions.sqf"
09.	Now use 'Pbo Manager' to make it a pbo file again and upload it to your Server. // rightclick dayz_server folder -> pbo manager -> pack into "dayz_server.pbo"
10.	CHECK IF YOUR MISSIONFILE HAS THIS LINE IN THE INIT.SQF:
	#include "\z\addons\dayz_code\system\REsec.sqf"
	IF YES -> HAS TO BE REMOVED!
	IF YOUR MISSIONFILE INIT.SQF HAS THOSE LINES
	dayz_antihack = 0; // DayZ Antihack / 1 = enabled // 0 = disabled
	dayz_REsec = 0; // DayZ RE Security / 1 = enabled // 0 = disabled
	SET IT LIKE THIS. THEY BOTH HAVE TO BE   = 0;
	Picture (everyone likes them):
	REMOVE THE COLORED THINGS (if you have not done that yet):
		http://files.dayzantihack.de/remove_from_mpmission_init.sqf.png
		which is this:
			[] execVM "\z\addons\dayz_code\system\antihack.sqf";
		remove this line completely or you can not teleport.
11.	Do not forget to replace your current BE filters with the one you got with the AntiHack.
		/000.000.000.000_0000/USERNAME_MasterConfiguration/BattlEye/
12.	In the "AHconfig.sqf" you will find:
		/*  LOW ADMIN HERE        */ _LAdmins = ["0","0","0"]; //do not have a , at the end.
		/*  NORMAL ADMIN HERE     */ _NAdmins = ["0","0","0"]; //do not have a , at the end.
		/*  SUPER ADMIN HERE      */ _SAdmins = ["0","0","0"]; //do not have a , at the end.
		You have to add your PlayerID (NOT GUID) in there to become an admin!
			https://www.youtube.com/watch?v=F-_W-yfPQhM
13.	Ingame Press your _OpenMenuKey Key and Magic happens. (F2 by default!)

Have a great day and an awesome expierience,
chris aka infiSTAR
/* *******************Developer : infiSTAR (infiSTAR23@gmail.com)******************* */
/* ******************Copyright � 2014 infiSTAR all rights reserved****************** */
/* *********************************www.infiSTAR.de********************************* */